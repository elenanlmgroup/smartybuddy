<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\Http\Requests;
use App\User;
use App\Child;

class ParentController extends Controller
{
   public function index() {
		$user = Auth::user();
    	$childs = Child::where('parent_id',$user->id)->get();

    	return view('parent',['childs'=>$childs]);
	} 

	public function edit() {
		$user = Auth::user();
    	$info = User::where('id',$user->id)->get();

    	return view('edit_parent',['info'=>$info]);
	}

	public function update(Request $request) {

		$this->validate($request, [
        'name' => 'required|max:255',
        'email' => 'required|email|max:255',
        'password' => 'min:6|confirmed',
    	]);

		$parentup = Auth::user('id');
       		$parentup->name=$request->name;
            $parentup->email=$request->email;
            $parentup->weekly_reports=$request->weekly_reports;
            $parentup->prom_emails=$request->prom_emails;
            $parentup->password = bcrypt($request['password']);
            $parentup->save();
        return redirect('/');
	}
}
