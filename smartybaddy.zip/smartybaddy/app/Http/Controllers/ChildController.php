<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\Http\Requests;
use App\Child;
use App\User;


class ChildController extends Controller

    
{
    public function edit() {

    	return view('add_child');
    }

    public function store(Request $request) {

		$this->validate($request, [
        'name' => 'required|max:255',
        'password' => 'min:6|confirmed',
    	]);

			
			$child = Child::create($request->all());


        return redirect('/');
	}
}
