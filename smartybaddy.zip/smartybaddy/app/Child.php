<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Child extends Model
{
    protected $table="childs";
    protected $fillable=['name','parent_id','grade','username','password'];

     public function parent()
    {
        return $this->belongsTo('App\User','parent_id','id');
    }
}
