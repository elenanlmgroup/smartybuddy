@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <a href="/" class="btn btn-default">back</a>
                    <a href="/add_child" class="btn btn-default">Add a Student</a>
                    <a href="/edit_student" class="btn btn-default"> My Student</a>

                  <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ action('ParentController@update') }}">
                        {{ csrf_field() }}
                        @foreach($info as $inf)
                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">First name, Last name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="{{ $inf->name }}">

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ $inf->email }}">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                          <label for="weekly" class="col-md-4 control-label">Weekly Reports</label>

                            <div class="col-md-6">
                            @if($inf->weekly_reports == '0')
                                <label><input type="radio" id="weekly" name="weekly_reports" value="0" checked>no</label>
                                <label><input type="radio" id="weekly" name="weekly_reports" value="1">Yes</label>
                            @else
                            <label><input type="radio" id="weekly" name="weekly_reports" value="0">no</label>
                            <label><input type="radio" id="weekly" name="weekly_reports" value="1" checked>Yes</label>
                            @endif
                            </div>
                            
                        </div>
                        
                        <div class="form-group">
                           
                       
                          <label for="emails" class="col-md-4 control-label">Promotion Emails</label>
                            <div class="col-md-6">
                            @if($inf->prom_emails == '0')
                                <label><input type="radio" id="emails" name="prom_emails" value="0" checked>no</label>
                                <label><input type="radio" id="emails" name="prom_emails" value="1">Yes</label>
                            @else
                                <label><input type="radio" id="emails" name="prom_emails" value="0">no</label>
                                <label><input type="radio" id="emails" name="prom_emails" value="1" checked>Yes</label>
                            @endif
                            </div>
                        </div>



                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label"> Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                     
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Save Update
                                </button>
                            </div>
                        </div>
                    </form>
                       @endforeach
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
