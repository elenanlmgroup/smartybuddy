@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <a href="/edit_parent" class="btn btn-default">Edit Profile</a>
                    <a href="/add_child" class="btn btn-default">Add a Student</a>
                    <a href="/edit_student" class="btn btn-default"> My Student</a>

                    <p><b>My Student</b></p>
                    <table class="table">
                        <tr>
                            <th>name</th>
                            <th>grade</th>
                            <th>username</th>
                            <th>date register</th>
                        </tr>
                        @foreach($childs as $child)
                        <tr>
                            <td>{{ $child->name }}</td>
                            <td>{{ $child->grade }}</td>
                            <td>{{ $child->username }}</td>
                            <td>{{ date('d.m.y H:i',strtotime($child->created_at)) }}</td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
