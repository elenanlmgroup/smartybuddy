<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <a href="/edit_parent" class="btn btn-default">Edit Profile</a>
                    <a href="/add_child" class="btn btn-default">Add a Student</a>
                    <a href="/edit_student" class="btn btn-default"> My Student</a>

                    <p><b>My Student</b></p>
                    <table class="table">
                        <tr>
                            <th>name</th>
                            <th>grade</th>
                            <th>username</th>
                            <th>date register</th>
                        </tr>
                        <?php foreach($childs as $child): ?>
                        <tr>
                            <td><?php echo e($child->name); ?></td>
                            <td><?php echo e($child->grade); ?></td>
                            <td><?php echo e($child->username); ?></td>
                            <td><?php echo e(date('d.m.y H:i',strtotime($child->created_at))); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>